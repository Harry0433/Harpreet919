using System;

namespace MethodAssignment
{
    class MathOperations
    {
        public void DoMath(int firstNumber, int secondNumber)
        {
            int result = firstNumber * 5;
            Console.WriteLine("Math result from first number: " + result);
            Console.WriteLine("Second number is: " + secondNumber);
        }
    }
}
