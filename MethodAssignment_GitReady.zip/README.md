
# Method Assignment – C# Console App

This project demonstrates:
- Creating a class with a void method
- Performing operations on parameters
- Calling a method with positional and named parameters
- Adding full comments for clarity

## How to Run
1. Open the folder in Visual Studio or VS Code.
2. Build and run the project.

## Files Included
- Program.cs – Main entry point
- MathOperations.cs – Contains the DoMath method
- MethodAssignment.csproj – Project configuration
