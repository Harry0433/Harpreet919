using System;

namespace MethodAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            MathOperations math = new MathOperations();
            math.DoMath(4, 10);
            math.DoMath(firstNumber: 7, secondNumber: 25);
            Console.ReadLine();
        }
    }
}
